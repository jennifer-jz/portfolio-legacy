# Switch to root folder
cd react_hour_selector

# Install react environment and modules
npm install create-react-app
npm install

# Run the app
npm start

# Check browser
http://localhost:3000/
 