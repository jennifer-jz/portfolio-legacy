// #8. Given the following array, write an ES6 expression to return all the
// first names
// const ducks = [
// { first: 'Stan' , last: 'duck' },
// { first: 'Steve' , last: 'duck' },
// { first: 'Kyle' , last: 'duck' },
// ];

const ducks = [
{ first: 'Stan' , last: 'duck' },
{ first: 'Steve' , last: 'duck' },
{ first: 'Kyle' , last: 'duck' },
];

// ducks.forEach(function(duck){
// 	console.log(duck.first);
// });

var newducks = [];
// newducks = ducks.map(function(duck){
// 	return duck.first;
// });

newducks = ducks.map(duck => duck.first);

console.log('first names of ducks');
console.log(newducks);

