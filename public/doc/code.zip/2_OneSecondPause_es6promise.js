// #2. Wait a second
// Add a one second pause between these logs.

var Promise = require("es6-promise");

async function test(){
	let x = 0 ;
	var mypromise = new Promise((resolve, reject) => { // (A)

        console.log( 'Value1:' , ++x);
		setTimeout(function(){
			resolve(x);
		}, 1000);

    });

    var mypromise2 = new Promise((resolve, reject) => { // (A)

	    mypromise.then(function(x){
	    	console.log( 'Value2:' , ++x);
	    	//console.log(x);
	    	resolve(x);
    	});

    });

    return mypromise2;
}

var result = test();

result.then(function(x){
	console.log('function return');
	console.log(x);
});