// #3. Dedupe the following array using a hash table
// const users = [
// { id: 1 , email: 'foo@example.com' },
// { id: 2 , email: 'bar@example.com' },
// { id: 1 , email: 'bin@example.com' },
// ];


const users = [
{ id: 1 , email: 'foo@example.com' },
{ id: 2 , email: 'bar@example.com' },
{ id: 1 , email: 'bin@example.com' },
];

var users_hash = [];
users.forEach(function(user){
	var email = user.email;
	users_hash[email] = user;
});

console.log(users_hash);
console.log('user foo@example.com');
console.log(users_hash['foo@example.com']);
console.log('user bar@example.com');
console.log(users_hash['bar@example.com']);
console.log('user bin@example.com');
console.log(users_hash['bin@example.com']);
