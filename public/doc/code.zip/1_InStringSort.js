// #1. Write an in-String Sort
// Write a function that receives a string with mixed letters, numbers, and symbols. The function
// should sort all the groups of letters within the string and return the result. An example of
// calling this function would be:

// sortGroupsOfLetters( 'x5*RnEM*BLL8nX@3' );
// // Result: BLL5*RnEM*nX8x@3


function sortGroupsOfLetters(input){
	var inputstr = input;
	var i = 0;
	var items = [];
	var match = inputstr.match(/[a-z]+/i);

	while(match != null && inputstr.length > 0){
		if (match.index != 0){
			var item = {id: i, str: inputstr.substring(0, match.index), istosort: 0 };
			items.push(item);
			i++;
		}
		var item = {id: i, str: String(match), istosort: 1 };
		items.push(item);
		i++;
		var endindex = match.index + String(match).length;

		inputstr = inputstr.substring(endindex, inputstr.length);
		match = inputstr.match(/[a-z]+/i);
		
		// console.log('inputstr: ' + inputstr);
	}

	if (inputstr.length > 0){
		var item = {id: i, str: inputstr, istosort: 0 };
		items.push(item);
	}

	// console.log('items');
	// console.log(items);

	var itemsToSort = [];
	items.forEach(function(item){
		if (item.istosort == 1){
			itemsToSort.push(item);
		}
	});

	// console.log('itemsToSort');
	// console.log(itemsToSort);

	itemsToSort.sort(function(a, b){
		if (a.str < b.str){
			return -1;
		}
		else if (a.str > b.str){
			return 1;
		}
		else{
			return 0;
		}
	});

	// console.log('itemsToSort sorted');
	// console.log(itemsToSort);

	var j = 0;
	items.forEach(function(item, index){
		if (item.istosort == 1){
			items[index] = itemsToSort[j];

			j++;
		}
	});

	// console.log('items sorted');
	// console.log(items);

	var result = "";
	items.forEach(function(item, index){
		result += item.str;
	});

	return result;
}

var result = sortGroupsOfLetters('x5*RnEM*BLL8nX@3');

console.log('InStringSort result for x5*RnEM*BLL8nX@3');
console.log(result);