// #11. Write a function to merge these two arrays.
// const data1 = [
// {id: 1 , name: 'Aaa' , value: 10 },
// {id: 2 , name: 'Bbb' , value: 20 },
// {id: 3 , name: 'Ccc' , value: 30 },
// {id: 4 , name: 'Ddd' , value: 40 },
// {id: 5 , name: 'Eee' , value: 50 },
// ];
// const data2 = [
// {id: 3 , name: 'Ccc' , value: 30 },
// {id: 4 , name: 'Ddd' , value: 40 },
// {id: 5 , name: 'Eee' , value: 50 },
// {id: 6 , name: 'Fff' , value: 60 },
// {id: 7 , name: 'Ggg' , value: 70 },
// ];

const data1 = [
{id: 1 , name: 'Aaa' , value: 10 },
{id: 2 , name: 'Bbb' , value: 20 },
{id: 3 , name: 'Ccc' , value: 30 },
{id: 4 , name: 'Ddd' , value: 40 },
{id: 5 , name: 'Eee' , value: 50 },
];
const data2 = [
{id: 3 , name: 'Ccc' , value: 30 },
{id: 4 , name: 'Ddd' , value: 40 },
{id: 5 , name: 'Eee' , value: 50 },
{id: 6 , name: 'Fff' , value: 60 },
{id: 7 , name: 'Ggg' , value: 70 },
];

function mergeArray(data1, data2){
	var mydata1 = JSON.parse(JSON.stringify(data1));
	var mydata2 = JSON.parse(JSON.stringify(data2));

	var data_merged = [];
	mydata1.forEach(function(item1){

		function matchitem(item){
			if (JSON.stringify(item) == JSON.stringify(item1)){
				return true;
			}
			else{
				return false;
			}
		}
		var index = mydata2.findIndex(matchitem);
		if (index < 0){
			data_merged.push(item1);
		}
		else{
			data_merged.push(item1);
			mydata2.splice(index, 1);

			//console.log(mydata2);
		}

	});

	mydata2.forEach(function(item2){
		data_merged.push(item2);
	});

	return data_merged;
}

var result = mergeArray(data1, data2);
console.log('merged array');
console.log(result);