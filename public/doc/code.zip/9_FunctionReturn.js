function currentUser () {
const users = [
{
name: 'John Doe' ,
}
]

console.log(users[ 0 ].name);
return 
{

currentUserName: users[ 0 ].name
}
}

var result = currentUser();
console.log(result);

function currentUser2 () {
const users = [
{
name: 'John Doe' ,
}
]

console.log(users[ 0 ].name);
var newuser = {

currentUserName: users[ 0 ].name
};
return newuser;

}

var result2 = currentUser2();
console.log(result2);

function currentUser3 () {
const users = [
{
name: 'John Doe' ,
}
]

console.log(users[ 0 ].name);
// var newuser;
newuser = {

currentUserName: users[ 0 ].name
}
return newuser;

}

var result3 = currentUser3();
console.log(result3);

function currentUser4 () {
const users = [
{
name: 'John Doe' ,
}
]

console.log(users[ 0 ].name);
// var newuser;

return {

currentUserName: users[ 0 ].name
}

}

var result4 = currentUser4();
console.log(result4);