var q = require('q');

async function test() { 
var defered = q.defer();
let x = 0 ;

console.log( 'Value1:' , ++x);
q.delay(1000).then(function(){
    console.log( 'Value2:' , ++x);
}).then(function(){
	defered.resolve(x);
});
  return defered.promise;
}

test();